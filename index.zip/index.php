<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="index.php" method="post">
        <input type="text" name="num1" placeholder="Numero 1" value="<?php echo isset($_POST['num1']) ? htmlspecialchars($_POST['num1']) : ''; ?>">
        <input type="text" name="num2" placeholder="Numero 2" value="<?php echo isset($_PSOT['num2']) ? htmlspecialchars($_POST['num2']) : ''; ?>">
        <div class="main-content">
            <input type="submit" name="operation" value="+">
            <input type="submit" name="operation" value="-">
            <input type="submit" name="operation" value="*">
            <input type="submit" name="operation" value="/">
            <input type="reset" value="limpar">
        </div> 
        <div>
            <?php
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $num1 = $_POST['num1'];
                    $num2 = $_POST['num2'];
                    $operation = $_POST['operation'];

                    if (is_numeric($num1) && is_numeric($num2)) {
                        switch ($operation) {
                            case '+';
                                $result = $num1 + $num2;
                                break;
                            case '-';
                                $result = $num1 + $num2;
                                break;
                            case '*';
                                $result = $num1 + $num2;
                                break;
                            case '/';
                                $result = $num1 + $num2;
                                if ($num2 != 0) {
                                    $result = $num1 / $num2;
                                } else {
                                    $result = 'Erro: Divisão por zero!';
                                }
                                break;
                            default:
                                $result = 'Operação Inválida';
                        }
                        echo "<h3>Resultado: $result</h3>";
                    } else {
                        echo "<h3>Erro: Insira Numeros Validos!</h3>";
                    }
                }
            ?>
        </div>
    </form>
</body>
</html>